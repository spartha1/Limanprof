INSERT INTO roles (nombre, descripcion) VALUES
('admin', 'Administrador del sistema'),
('cliente', 'Cliente registrado'),
('usuario', 'Usuario estándar');
