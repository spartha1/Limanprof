<?php
// Configure session settings before starting the session
ini_set('session.cookie_lifetime', 0);
ini_set('session.use_only_cookies', 1);
session_start();
?>
